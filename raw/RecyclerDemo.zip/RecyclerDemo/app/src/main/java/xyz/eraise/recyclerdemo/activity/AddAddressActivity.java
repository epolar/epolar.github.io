package xyz.eraise.recyclerdemo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatEditText;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import xyz.eraise.recyclerdemo.R;
import xyz.eraise.recyclerdemo.pojo.AddressInfo;

/**
 * 创建日期： 2016/8/9.
 */
public class AddAddressActivity extends AppCompatActivity implements View.OnClickListener {

    private AppCompatEditText etName;
    private AppCompatEditText etPhone;
    private AppCompatEditText etAddress;
    private Button btnSave;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_address);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        actionBar.setDisplayHomeAsUpEnabled(true);

        findViews();
    }

    private void findViews() {
        etName = (AppCompatEditText) findViewById(R.id.et_name);
        etPhone = (AppCompatEditText) findViewById(R.id.et_phone);
        etAddress = (AppCompatEditText) findViewById(R.id.et_address);
        btnSave = (Button) findViewById(R.id.btn_save);

        btnSave.setOnClickListener( this );
    }

    private void saveAddress() {
        String name = etName.getText().toString();
        if (name.length() == 0) {
            etName.setError(getString(R.string.contact_cannot_be_empty));
            etName.requestFocus();
            return;
        }

        String phone = etPhone.getText().toString();
        if (phone.length() == 0) {
            etPhone.setError(getString(R.string.contact_number_cannot_be_empty));
            etPhone.requestFocus();
            return;
        }

        String address = etAddress.getText().toString();
        if (address.length() == 0) {
            etAddress.setError(getString(R.string.contact_address_cannot_be_empty));
            etAddress.requestFocus();
            return;
        }

        AddressInfo info = new AddressInfo();
        info.name = name;
        info.phone = phone;
        info.address = address;
        Intent resultIntent = new Intent();
        resultIntent.putExtra("data", info);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v == btnSave) {
            saveAddress();
        }
    }

}
