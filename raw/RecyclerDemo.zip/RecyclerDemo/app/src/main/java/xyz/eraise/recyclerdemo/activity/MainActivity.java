package xyz.eraise.recyclerdemo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import xyz.eraise.recyclerdemo.R;
import xyz.eraise.recyclerdemo.adapter.MyAdapter;
import xyz.eraise.recyclerdemo.adapter.MyDecorator;
import xyz.eraise.recyclerdemo.pojo.AddressInfo;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_ADD_ADDRESS = 1001;

    private RecyclerView mRecyclerView;
    private MyAdapter mAdapter;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_ADD_ADDRESS) {
                AddressInfo addressInfo = data.getParcelableExtra("data");
                if (addressInfo != null) {
                    mAdapter.add(addressInfo);
                    // 单行更新 - 插入，刷新的是列表的最后一条
                    mAdapter.notifyItemInserted(mAdapter.getItemCount() - 1);
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViews();
        initRecyclerView();

        mockInitData();
    }

    private void findViews() {
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
    }

    private void initRecyclerView() {
        mAdapter = new MyAdapter(this);
        // 设置布局方式为线性垂直
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.addItemDecoration(new MyDecorator());
        // 设置触摸
        ItemTouchHelper touchHelper = new ItemTouchHelper(new ItemTouchHelper.Callback() {
            @Override
            public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
                // 设置为允许向左滑动，允许向上向下托拽
                return makeFlag(ItemTouchHelper.ACTION_STATE_DRAG,
                            ItemTouchHelper.UP | ItemTouchHelper.DOWN)
                        | makeFlag(ItemTouchHelper.ACTION_STATE_SWIPE, ItemTouchHelper.LEFT);
            }

            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                // 改变数据位置
                int position = viewHolder.getAdapterPosition();
                int targetPosition = target.getAdapterPosition();
                if (position == targetPosition) {
                    return false;
                }
                Log.d("drag", position + ", " + targetPosition);
                AddressInfo info = mAdapter.getAddressInfo(position);
                mAdapter.remove(position);
                mAdapter.add(targetPosition, info);
                mAdapter.notifyItemMoved(position, targetPosition);

                return true;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                // getAdapterPosition可以得到 ViewHolder 在 Adapter 中的位置
                int position = viewHolder.getAdapterPosition();
                mAdapter.remove(position);
                mAdapter.notifyItemRemoved(position);
            }
        });
        // 把 ItemTouchHelper 附加到 RecyclerView 上
        touchHelper.attachToRecyclerView(mRecyclerView);
    }

    /**
     * 初始化几条数据
     */
    private void mockInitData() {
        mAdapter.add(new AddressInfo("白精灵", "120", "医院"));
        mAdapter.add(new AddressInfo("红精灵", "119", "灭火中心"));
        mAdapter.add(new AddressInfo("绿精灵", "110", "特别行动中心"));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_add:
                startActivityForResult(new Intent(this, AddAddressActivity.class), REQUEST_ADD_ADDRESS);
//                mAdapter.add(0, new AddressInfo("蓝精灵", "111", "地球"));
//                mAdapter.notifyItemInserted(0);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}
