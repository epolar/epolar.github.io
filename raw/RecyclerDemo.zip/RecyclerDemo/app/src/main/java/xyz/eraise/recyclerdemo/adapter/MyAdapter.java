package xyz.eraise.recyclerdemo.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import java.util.ArrayList;

import xyz.eraise.recyclerdemo.R;
import xyz.eraise.recyclerdemo.pojo.AddressInfo;

/**
 * 创建日期： 2016/8/9.
 */
public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

    private Context context;
    private ArrayList<AddressInfo> data;

    public MyAdapter(Context context) {
        this.context = context;
        data = new ArrayList<>();
    }

    public void add(AddressInfo info) {
        data.add(info);
    }

    public void add(int position, AddressInfo info) {
        data.add(position, info);
    }

    public void remove(AddressInfo info) {
        data.remove(info);
    }

    public void remove(int position) {
        data.remove(position);
    }

    public AddressInfo getAddressInfo(int position) {
        return data.get(position);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.item_address, parent, false));
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        AddressInfo info = data.get(position);

        holder.tvName.setText(info.name);
        holder.tvPhone.setText(info.phone);
        holder.tvAddress.setText(holder.tvAddress.getResources().getString(R.string.address_, info.address));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
