package xyz.eraise.recyclerdemo.adapter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.View;

/**
 * ItemDecoration 是用来装饰 Item 的，用它可以做许多事情， ItemTouchHelper 就是它的子类，<br/>
 * 通过 ItemDecoration 可以去绘制分割线、自定义一个 OnClickListener 等
 * <br/>
 * <br/>
 * {@link #onDraw(Canvas, RecyclerView, RecyclerView.State)} 和 {@link #onDrawOver(Canvas, RecyclerView, RecyclerView.State)} 的区别是画在上面还是画在下面，over画的东西将会覆盖在 Item 之上
 */
public class MyDecorator extends RecyclerView.ItemDecoration {

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        if (parent.getChildAdapterPosition(view) == 0)  // getChildAdapterPosition 可以得到 childView 在 Adapter 中的 position
            outRect.top = 0;
        else {
            outRect.top = dp2px(10, view.getContext());
        }
    }

    private int dp2px(int dp, Context context) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }
}

