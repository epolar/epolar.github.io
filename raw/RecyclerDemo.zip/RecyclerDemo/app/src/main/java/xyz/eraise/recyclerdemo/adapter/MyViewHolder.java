package xyz.eraise.recyclerdemo.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import xyz.eraise.recyclerdemo.R;

/**
 * 创建日期： 2016/8/9.
 */
public class MyViewHolder extends RecyclerView.ViewHolder {

    public TextView tvName;
    public TextView tvPhone;
    public TextView tvAddress;

    public MyViewHolder(View itemView) {
        super(itemView);

        findViews();
    }

    private void findViews() {
        tvName = (TextView) itemView.findViewById(R.id.tv_name);
        tvPhone = (TextView) itemView.findViewById(R.id.tv_phone);
        tvAddress = (TextView) itemView.findViewById(R.id.tv_address);
    }
}
