package xyz.eraise.recyclerdemo.pojo;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 创建日期： 2016/8/9.
 * 地址信息
 */
public class AddressInfo implements Parcelable {

    public String name;

    public String phone;

    public String address;

    public AddressInfo() {}

    public AddressInfo(String name, String phone, String address) {
        this.name = name;
        this.phone = phone;
        this.address = address;
    }

    private AddressInfo(Parcel parcel) {
        name = parcel.readString();
        phone = parcel.readString();
        address = parcel.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(phone);
        dest.writeString(address);
    }

    public static Creator<AddressInfo> CREATOR = new Creator<AddressInfo>() {
        @Override
        public AddressInfo createFromParcel(Parcel source) {
            return new AddressInfo(source);
        }

        @Override
        public AddressInfo[] newArray(int size) {
            return new AddressInfo[0];
        }
    };
}
